//
//  InterfaceController.swift
//  10-Picker WatchKit Extension
//
//  Created by padalingam agasthian on 23/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var color: WKInterfaceLabel!
    @IBOutlet var picker: WKInterfacePicker!
    
    var itemList: [(String, String)] = [
        ("Item 1", "Red"),
        ("Item 2", "Green"),
        ("Item 3", "Blue"),
        ("Item 4", "Yellow"),
        ("Item 5", "Indigo"),
        ("Item 6", "Violet") ]
    
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        let pickerItems: [WKPickerItem] = itemList.map
        {
            let pickerItem = WKPickerItem()
            pickerItem.caption = $0.0
            pickerItem.title = $0.1
            return pickerItem
        }
        picker.setItems(pickerItems)
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func pickerAction(value: Int)
    {
        color.setText(itemList[value].1)
    }
}
