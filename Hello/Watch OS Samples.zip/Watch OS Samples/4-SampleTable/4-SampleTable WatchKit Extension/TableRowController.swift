//
//  TableRowController.swift
//  4-SampleTable
//
//  Created by padalingam agasthian on 22/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit

class TableRowController: NSObject
{
    @IBOutlet var name: WKInterfaceLabel!
}
