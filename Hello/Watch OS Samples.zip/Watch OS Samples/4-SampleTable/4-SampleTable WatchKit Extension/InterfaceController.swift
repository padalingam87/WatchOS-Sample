//
//  InterfaceController.swift
//  4-SampleTable WatchKit Extension
//
//  Created by padalingam agasthian on 22/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController
{
    @IBOutlet var table: WKInterfaceTable!
    @IBOutlet var name: WKInterfaceLabel!
    
    let names = ["Vineet","Tharani","Pavithra","Jaya","Sai","Rajesh","Peter","Mark"]
    
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        table.setNumberOfRows(names.count, withRowType: "rowController")
        for (index, name) in names.enumerate()
        {
            let row = table.rowControllerAtIndex(index) as! TableRowController
            row.name.setText(name)
        }
        
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    override func contextForSegueWithIdentifier(segueIdentifier: String, inTable table: WKInterfaceTable, rowIndex: Int) -> AnyObject?
    {
        let clickedValue = names[rowIndex]
        return clickedValue
    }

}
