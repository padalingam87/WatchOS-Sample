//
//  RowController.swift
//  38-BackgroundTransfer
//
//  Created by padalingam agasthian on 03/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit

class RowController: NSObject
{
    @IBOutlet var heading: WKInterfaceLabel!
    @IBOutlet var content: WKInterfaceLabel!
}
