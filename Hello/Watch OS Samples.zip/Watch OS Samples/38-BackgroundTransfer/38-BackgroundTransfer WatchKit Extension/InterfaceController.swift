//
//  InterfaceController.swift
//  38-BackgroundTransfer WatchKit Extension
//
//  Created by padalingam agasthian on 03/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity

class InterfaceController: WKInterfaceController
{
    @IBOutlet var table: WKInterfaceTable!
    
    let dateFormatter = NSDateFormatter()
    var items: [NSDictionary] = []
    
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        dateFormatter.dateFormat = "EEEE"
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        self.items.removeAll()
        
        if let newItems = NSUserDefaults.standardUserDefaults().objectForKey("items") as? [NSDictionary]
        {
            self.items = newItems
            self.table.setNumberOfRows(self.items.count, withRowType: "BasicRow")
            
            for i in 0..<self.items.count
            {
                if let row = self.table.rowControllerAtIndex(i) as? RowController
                {
                    print(self.items[i])
                    let date = self.items[i]["date"] as! NSDate
                    row.heading.setText("\(date)")
                    row.content.setText(self.items[i]["day"] as? String)
                }
            }
        }

    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func newItem()
    {
        let date = NSDate()
        
        let item = ["date": date, "day": dateFormatter.stringFromDate(date)]
        self.items.append(item)
        print(self.items)
        
        if self.items.count == 1
        {
            self.table.setNumberOfRows(1, withRowType: "BasicRow")
        } else {
            self.table.insertRowsAtIndexes(NSIndexSet(index: items.count-1), withRowType: "BasicRow")
        }
        
        if let row = self.table.rowControllerAtIndex(items.count-1) as? RowController {
            row.heading.setText("\(date)")
            row.content.setText(item["day"] as? String)
        }
        
        WCSession.defaultSession().transferUserInfo(item)
    }

   
}
