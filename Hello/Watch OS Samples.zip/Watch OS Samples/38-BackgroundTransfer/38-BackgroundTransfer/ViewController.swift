//
//  ViewController.swift
//  38-BackgroundTransfer
//
//  Created by padalingam agasthian on 03/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UITableViewController
{
 var items: [NSDictionary] = []
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.items.removeAll()
        if let newItems = NSUserDefaults.standardUserDefaults().objectForKey("items") as? [NSDictionary]
        {
            print("True")
            self.items = newItems
        }
        
        print(NSUserDefaults.standardUserDefaults().objectForKey("items"))
        
        self.tableView.reloadData()
        self.setNeedsStatusBarAppearanceUpdate()
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func newItem(sender: AnyObject)
    {
        let date = NSDate()
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "EEEE"
        
        let item = ["date": date, "day": dateFormatter.stringFromDate(date)]
        self.items.append(item)
        self.tableView.reloadData()
        
        WCSession.defaultSession().transferUserInfo(item)
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("Basic Cell", forIndexPath: indexPath)
        let item = items[indexPath.row]
        if let date = item["date"] as? NSDate, let day = item["day"] as? String
        {
            cell.textLabel?.text = "\(date)"
            cell.detailTextLabel?.text = day
        }
        return cell
    }

}

