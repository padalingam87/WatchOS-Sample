//
//  InterfaceController.swift
//  17-ImageAnimate WatchKit Extension
//
//  Created by padalingam agasthian on 24/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var archImage: WKInterfaceImage!
    @IBOutlet var activityImage: WKInterfaceImage!
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
    }

    override func willActivate()
    {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        archImage.setImageNamed("arc-")
        archImage.startAnimatingWithImagesInRange(NSMakeRange(0, 60), duration: 1.0, repeatCount: 0)
        
        activityImage.setImageNamed("activity-")
        activityImage.startAnimatingWithImagesInRange(NSMakeRange(0, 62), duration: 1.0, repeatCount: 0)
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
