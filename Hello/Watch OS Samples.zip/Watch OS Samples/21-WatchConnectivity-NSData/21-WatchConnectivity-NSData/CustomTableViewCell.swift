//
//  CustomTableViewCell.swift
//  21-WatchConnectivity-NSData
//
//  Created by padalingam agasthian on 25/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell
{
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
