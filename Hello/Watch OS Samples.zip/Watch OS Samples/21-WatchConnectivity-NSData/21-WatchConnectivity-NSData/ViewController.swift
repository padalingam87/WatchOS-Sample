//
//  ViewController.swift
//  21-WatchConnectivity-NSData
//
//  Created by padalingam agasthian on 25/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,WCSessionDelegate
{
    var imageList = ["imageOne.jpg","imageTwo.jpg","imageThree.jpg"]
    var labelList = ["Letter A","Letter B","Letter C"]
    var session:WCSession!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        if (WCSession.isSupported())
        {
            session = WCSession.defaultSession()
            session.delegate = self
            session.activateSession()
        }
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

  

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        let image = UIImage.init(named: imageList[indexPath.row])
        let data = UIImageJPEGRepresentation(image!, 1)
        session.sendMessageData(data!, replyHandler: nil, errorHandler: nil)
        session.sendMessage(["letter":labelList[indexPath.row]], replyHandler: nil, errorHandler: nil)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return imageList.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let identifier = "SimpleTable"
        let cell = tableView.dequeueReusableCellWithIdentifier(identifier)
        cell?.textLabel?.text = labelList[indexPath.row]
        return cell!
    }
}

