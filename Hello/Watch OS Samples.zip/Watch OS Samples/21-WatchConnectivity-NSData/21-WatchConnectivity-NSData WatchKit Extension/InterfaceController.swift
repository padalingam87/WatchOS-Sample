//
//  InterfaceController.swift
//  21-WatchConnectivity-NSData WatchKit Extension
//
//  Created by padalingam agasthian on 25/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity

class InterfaceController: WKInterfaceController,WCSessionDelegate {

    @IBOutlet var image: WKInterfaceImage!
    @IBOutlet var label: WKInterfaceLabel!
    var session:WCSession!
    
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        if (WCSession.isSupported())
        {
            session = WCSession.defaultSession()
            session.delegate = self
            session.activateSession()
        }
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func session(session: WCSession, didReceiveMessageData messageData: NSData)
    {
        image.setImageData(messageData)
    }
    
    func session(session: WCSession, didReceiveMessage message: [String : AnyObject])
    {
        label.setText(message["letter"] as? String)
    }

}
