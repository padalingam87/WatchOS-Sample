//
//  InterfaceController.swift
//  15-Accessability WatchKit Extension
//
//  Created by padalingam agasthian on 24/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController
{

    @IBOutlet var demoLabel: WKInterfaceLabel!
    
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        demoLabel.setIsAccessibilityElement(true)
        demoLabel.setAccessibilityLabel("Time Pass")
        // Configure interface objects here.
    }

    override func willActivate()
    {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
