//
//  ComplicationController.swift
//  23-ComplicationOne WatchKit Extension
//
//  Created by padalingam agasthian on 26/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import ClockKit


class ComplicationController: NSObject, CLKComplicationDataSource {
    
    // MARK: - Timeline Configuration
    
    struct Content
    {
        var image:UIImage
        var headerText:String
        var rowOneColumnOne:String
        var rowOneColumnTwo:String
        var rowTwoColumnOne:String
        var rowTwoColumnTwo:String
        
        var startDate:NSDate
        var length:NSTimeInterval
    }
     var contents = [
    Content(image: UIImage.init(named: "imageOne.jpg")!, headerText: "Letter A", rowOneColumnOne: "Apple", rowOneColumnTwo: "Alarm", rowTwoColumnOne: "Acid", rowTwoColumnTwo: "Atomic", startDate: NSDate(), length: 60*60*1),
    Content(image: UIImage.init(named: "imageTwo.jpg")!, headerText: "Letter B", rowOneColumnOne: "Ball", rowOneColumnTwo: "Baloon", rowTwoColumnOne: "Button", rowTwoColumnTwo: "Bottom", startDate: NSDate(timeIntervalSinceNow: 60*60*1), length: 60*60*1),
    Content(image: UIImage.init(named: "imageOne.jpg")!, headerText: "Letter C", rowOneColumnOne: "Cat", rowOneColumnTwo: "Catch", rowTwoColumnOne: "Call", rowTwoColumnTwo: "Cosmetics", startDate: NSDate(timeIntervalSinceNow: 60*60*1.9), length: 60*60*1)
    ]
    
    
    func getSupportedTimeTravelDirectionsForComplication(complication: CLKComplication, withHandler handler: (CLKComplicationTimeTravelDirections) -> Void)
    {
        handler([.Forward, .Backward])
    }
    
    func getTimelineStartDateForComplication(complication: CLKComplication, withHandler handler: (NSDate?) -> Void)
    {
        handler(nil)
    }
    
    func getTimelineEndDateForComplication(complication: CLKComplication, withHandler handler: (NSDate?) -> Void)
    {
        handler(nil)
    }
    
    func getPrivacyBehaviorForComplication(complication: CLKComplication, withHandler handler: (CLKComplicationPrivacyBehavior) -> Void) {
        handler(.ShowOnLockScreen)
    }
    
    // MARK: - Timeline Population
    
    func getCurrentTimelineEntryForComplication(complication: CLKComplication, withHandler handler: ((CLKComplicationTimelineEntry?) -> Void))
    {
        // Call the handler with the current timeline entry
        let content = contents[0]
        let template = CLKComplicationTemplateModularLargeTable()
        template.headerImageProvider = CLKImageProvider(onePieceImage: content.image)
        template.headerTextProvider = CLKSimpleTextProvider(text: content.headerText)
        template.row1Column1TextProvider = CLKSimpleTextProvider(text: content.rowOneColumnOne)
        template.row1Column2TextProvider = CLKSimpleTextProvider(text: content.rowOneColumnTwo)
        template.row2Column1TextProvider = CLKSimpleTextProvider(text: content.rowTwoColumnOne)
        template.row2Column2TextProvider = CLKSimpleTextProvider(text: content.rowTwoColumnTwo)
        let entry = CLKComplicationTimelineEntry(date: NSDate(timeInterval: 60*60 * -0.25, sinceDate: content.startDate), complicationTemplate: template)
        handler(entry)
        
    }
    
    func getTimelineEntriesForComplication(complication: CLKComplication, beforeDate date: NSDate, limit: Int, withHandler handler: (([CLKComplicationTimelineEntry]?) -> Void))
    {
        var entries: [CLKComplicationTimelineEntry] = []
        for content in contents
        {
            if entries.count < limit && content.startDate.timeIntervalSinceDate(date) > 0
            {
                let template = CLKComplicationTemplateModularLargeTable()
                template.headerImageProvider = CLKImageProvider(onePieceImage: content.image)
                template.headerTextProvider = CLKSimpleTextProvider(text: content.headerText)
                template.row1Column1TextProvider = CLKSimpleTextProvider(text: content.rowOneColumnOne)
                template.row1Column2TextProvider = CLKSimpleTextProvider(text: content.rowOneColumnTwo)
                template.row2Column1TextProvider = CLKSimpleTextProvider(text: content.rowTwoColumnOne)
                template.row2Column2TextProvider = CLKSimpleTextProvider(text: content.rowTwoColumnTwo)
                let entry = CLKComplicationTimelineEntry(date: NSDate(timeInterval: 60*60 * -0.25, sinceDate: content.startDate), complicationTemplate: template)
                entries.append(entry)
            }
        }
        handler(entries)
        handler(nil)
    }
    
    func getTimelineEntriesForComplication(complication: CLKComplication, afterDate date: NSDate, limit: Int, withHandler handler: (([CLKComplicationTimelineEntry]?) -> Void))
    {
        var entries: [CLKComplicationTimelineEntry] = []
        for content in contents
        {
           if entries.count < limit && content.startDate.timeIntervalSinceDate(date) > 0
           {
            let template = CLKComplicationTemplateModularLargeTable()
            template.headerImageProvider = CLKImageProvider(onePieceImage: content.image)
            template.headerTextProvider = CLKSimpleTextProvider(text: content.headerText)
            template.row1Column1TextProvider = CLKSimpleTextProvider(text: content.rowOneColumnOne)
            template.row1Column2TextProvider = CLKSimpleTextProvider(text: content.rowOneColumnTwo)
            template.row2Column1TextProvider = CLKSimpleTextProvider(text: content.rowTwoColumnOne)
            template.row2Column2TextProvider = CLKSimpleTextProvider(text: content.rowTwoColumnTwo)
            let entry = CLKComplicationTimelineEntry(date: NSDate(timeInterval: 60*60 * -0.25, sinceDate: content.startDate), complicationTemplate: template)
            entries.append(entry)
           }
        }
        handler(entries)
    }
    
    // MARK: - Update Scheduling
    
    func getNextRequestedUpdateDateWithHandler(handler: (NSDate?) -> Void) {
        // Call the handler with the date when you would next like to be given the opportunity to update your complication content
        handler(nil);
    }
    
    // MARK: - Placeholder Templates
    
    func getPlaceholderTemplateForComplication(complication: CLKComplication, withHandler handler: (CLKComplicationTemplate?) -> Void)
    {
        let template = CLKComplicationTemplateModularLargeTable()
        template.headerImageProvider = CLKImageProvider.init(onePieceImage: UIImage.init(named: "imageOne.jpg")!)
        template.headerTextProvider = CLKSimpleTextProvider(text: "My Heading")
        template.row1Column1TextProvider = CLKSimpleTextProvider(text: "Row1,1")
        template.row1Column2TextProvider = CLKSimpleTextProvider(text: "Row1,2")
        template.row2Column1TextProvider = CLKSimpleTextProvider(text: "Row2,1")
        template.row2Column2TextProvider = CLKSimpleTextProvider(text: "Row2,2")
        handler(template)
    }
    
}
