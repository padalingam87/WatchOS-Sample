//
//  TalkTableViewCell.swift
//  25-ComplicationThree
//
//  Created by padalingam agasthian on 26/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class TalkTableViewCell: UITableViewCell
{

    @IBOutlet weak var TalkImage: UIImageView!
    @IBOutlet weak var TalkTitle: UILabel!
    @IBOutlet weak var TalkSubtitle: UILabel!
    @IBOutlet weak var TalkSpeaker: UILabel!
    @IBOutlet weak var TalkTime: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
