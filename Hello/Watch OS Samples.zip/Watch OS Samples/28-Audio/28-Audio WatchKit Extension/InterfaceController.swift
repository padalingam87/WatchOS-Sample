//
//  InterfaceController.swift
//  28-Audio WatchKit Extension
//
//  Created by padalingam agasthian on 29/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    @IBOutlet var playBtn: WKInterfaceButton!
    @IBOutlet var label:WKInterfaceLabel!
    
    var player: WKAudioFilePlayer!
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        let filePath = "/Users/padalingam.a/Desktop/My Projects/Watch OS/Watch OS Samples/28-Audio/28-Audio WatchKit Extension/se_tap.m4a"
        let fileUrl = NSURL.fileURLWithPath(filePath)
        let asset = WKAudioFileAsset(URL: fileUrl)
        let playerItem = WKAudioFilePlayerItem(asset: asset)
        player = WKAudioFilePlayer(playerItem: playerItem)
    }

    override func willActivate()
    {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate()
    {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func play()
    {
        switch player.status
        {
        case .ReadyToPlay:
            label.setText("playing")
            player.play()
        case .Failed:
            label.setText("failed")
        case .Unknown:
            label.setText("unknown")
        }
    }

}
