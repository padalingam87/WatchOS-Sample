//
//  ViewController.swift
//  40-CustomNotification
//
//  Created by padalingam agasthian on 03/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
 let app = UIApplication.sharedApplication()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func rainAction(sender: AnyObject)
    {
        let alertTime = NSDate().dateByAddingTimeInterval(5)
        
        let notifyAlarm = UILocalNotification()
        
        notifyAlarm.fireDate = alertTime
        notifyAlarm.timeZone = NSTimeZone.defaultTimeZone()
        notifyAlarm.soundName = UILocalNotificationDefaultSoundName
        notifyAlarm.category = "WEATHER_CATEGORY"
        notifyAlarm.alertTitle = "Rain"
        notifyAlarm.alertBody = "It is going to rain"
        app.scheduleLocalNotification(notifyAlarm)
    }
    
    @IBAction func snowAction(sender: AnyObject)
    {
        let alertTime = NSDate().dateByAddingTimeInterval(5)
        
        let notifyAlarm = UILocalNotification()
        
        notifyAlarm.fireDate = alertTime
        notifyAlarm.timeZone = NSTimeZone.defaultTimeZone()
        notifyAlarm.soundName = UILocalNotificationDefaultSoundName
        notifyAlarm.category = "WEATHER_CATEGORY"
        notifyAlarm.alertTitle = "Snow"
        notifyAlarm.alertBody = "It is going to snow"
        app.scheduleLocalNotification(notifyAlarm)
    }

}

