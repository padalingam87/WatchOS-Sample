//
//  ViewController.swift
//  20-WatchConnectivity
//
//  Created by padalingam agasthian on 25/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UIViewController,WCSessionDelegate
{
    @IBOutlet weak var messageLabel: UILabel!

    var session:WCSession!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
      //  let image = UIImage.init(named: "imageOne.jpg")
        
       // _ = UIImageJPEGRepresentation(image!, 0.1)
        if(WCSession.isSupported())
        {
            self.session = WCSession.defaultSession()
            self.session.delegate = self
            self.session.activateSession()
        }
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sendToWatch(sender: AnyObject)
    {
        print(session.reachable)
        if session.reachable == true
        {
            session.sendMessage(["Key":"Msg Received From iOS"], replyHandler: nil, errorHandler: nil)
            let image = UIImage.init(named: "imageOne.jpg")
            let data = UIImageJPEGRepresentation(image!, 0.1)
            session.sendMessageData(data!, replyHandler: nil, errorHandler: nil)
        }
        
    }
    
//    func session(session: WCSession, didReceiveMessage message: [String : AnyObject])
//    {
//        
//    }
    
    func session(session: WCSession, didReceiveMessage message: [String : AnyObject], replyHandler: ([String : AnyObject]) -> Void)
    {
        dispatch_async(dispatch_get_main_queue(),
        {
                self.messageLabel.text = message["Key"] as? String
        })
        replyHandler(["ee":"ee"])
    }
}

