//
//  InterfaceController.swift
//  20-WatchConnectivity WatchKit Extension
//
//  Created by padalingam agasthian on 25/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity

class InterfaceController: WKInterfaceController,WCSessionDelegate
{
    @IBOutlet var messageLabel: WKInterfaceLabel!
    
    var session:WCSession!
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        if(WCSession.isSupported())
        {
            self.session = WCSession.defaultSession()
            self.session.delegate = self
            self.session.activateSession()
        }
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
       
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func session(session: WCSession, didReceiveMessage message: [String : AnyObject])
    {
        print("Watch Received")
        self.messageLabel.setText(message["Key"] as? String)
    }
    
    @IBAction func sendToiPhone()
    {
//        session.sendMessage(["Key":"Msg From Watch"], replyHandler: nil, errorHandler: nil)
        print(session.reachable)
        if session.reachable == true
        {
            session.sendMessage(["Key":"Msg From Watch"], replyHandler:
                { (response: [String : AnyObject]) -> Void in
                    print(response)
                }) { (NSError) -> Void in
                    print("no error")
            }
        }
       
    }

}
