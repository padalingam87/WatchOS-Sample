//
//  InterfaceController.swift
//  27-AnimateGroup WatchKit Extension
//
//  Created by padalingam agasthian on 29/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController
{

    @IBOutlet var spacerGroup: WKInterfaceGroup!
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
    }
    
    @IBAction func resetAction()
    {
        self.spacerGroup.setWidth(100)

    }
    
    @IBAction func animateAction()
    {
        animateWithDuration(0.3, animations:
        {
                self.spacerGroup.setWidth(0)
        })
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBOutlet var animateButton: WKInterfaceButton!
    @IBOutlet var buttonSpacerGroup: WKInterfaceGroup!
    var buttonMoved: Bool!
    @IBAction func animateMovingButton()
    {
        if (buttonMoved != true)
        {
            animateWithDuration(0.3, animations:
            {
                self.buttonSpacerGroup.setHeight(100)
            })
            
            buttonMoved = true
            animateButton.setTitle("Reset")
        } else
        {
            animateWithDuration(0.3, animations:
            {
                self.buttonSpacerGroup.setHeight(0)
            })
            
            buttonMoved = false
            animateButton.setTitle("Animate!")
        }
    }
}
