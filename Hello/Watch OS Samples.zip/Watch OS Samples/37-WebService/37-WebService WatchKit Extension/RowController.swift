//
//  RowController.swift
//  37-WebService
//
//  Created by padalingam agasthian on 02/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit

class RowController: NSObject
{

    @IBOutlet var countryName: WKInterfaceLabel!
}
