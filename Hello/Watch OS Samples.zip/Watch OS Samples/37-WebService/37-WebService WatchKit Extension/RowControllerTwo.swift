//
//  RowControllerTwo.swift
//  37-WebService
//
//  Created by padalingam agasthian on 03/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit

class RowControllerTwo: NSObject
{

    @IBOutlet var content: WKInterfaceLabel!
    @IBOutlet var heading: WKInterfaceLabel!
}
