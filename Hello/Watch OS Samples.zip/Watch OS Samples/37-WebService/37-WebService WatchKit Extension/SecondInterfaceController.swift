//
//  SecondInterfaceController.swift
//  37-WebService
//
//  Created by padalingam agasthian on 02/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class SecondInterfaceController: WKInterfaceController
{
    @IBOutlet var table: WKInterfaceTable!
    
    var listOfHeading = ["Country Name","Capital","Currency Code","population"]
    var listOfContent:[String] = []
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        let countryCode = context as! String
        print(countryCode)
        let url = NSURL(string: "http://api.geonames.org/countryInfoJSON?username=padalingam_87&country=\(countryCode)")
        let dataData = NSData(contentsOfURL: url!)
        let main = try? NSJSONSerialization.JSONObjectWithData(dataData!, options: NSJSONReadingOptions.AllowFragments)
        let dict = main as! [String:AnyObject]
        let array = dict["geonames"] as! NSArray
        let dictionaryData =  array[0] as! [String:AnyObject]
        listOfContent.append(dictionaryData["countryName"] as! String)
        listOfContent.append(dictionaryData["capital"] as! String)
        listOfContent.append(dictionaryData["currencyCode"] as! String)
        listOfContent.append(dictionaryData["population"] as! String)
        table.setNumberOfRows(listOfContent.count, withRowType: String(RowControllerTwo))
        for (index,content) in listOfContent.enumerate()
        {
            let row = table.rowControllerAtIndex(index) as? RowControllerTwo
            row?.heading.setText(listOfHeading[index])
            row?.content.setText(content)
        }
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
