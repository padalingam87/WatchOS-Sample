//
//  ViewController.swift
//  26-ChildAppToParent
//
//  Created by padalingam agasthian on 29/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,WCSessionDelegate
{
    @IBOutlet weak var tableView: UITableView!
    var session : WCSession!
    var listValue:[String] = ["0"]
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if (WCSession.isSupported())
        {
            session = WCSession.defaultSession()
            session.delegate = self
            session.activateSession()
        }
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return listValue.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let identifier = "SimpleTable"
        let cell = tableView.dequeueReusableCellWithIdentifier(identifier)
        cell?.textLabel?.text = listValue[indexPath.row]
        return cell!
    }
 
    func session(session: WCSession, didReceiveMessage message: [String : AnyObject])
    {
       dispatch_async(dispatch_get_main_queue(),
        {
                self.listValue.append((message["value"] as? String)!)
                self.tableView.reloadData()
        })
    }

}

