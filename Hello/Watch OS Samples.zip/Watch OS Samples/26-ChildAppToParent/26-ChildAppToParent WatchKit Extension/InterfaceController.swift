//
//  InterfaceController.swift
//  26-ChildAppToParent WatchKit Extension
//
//  Created by padalingam agasthian on 29/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity

class InterfaceController: WKInterfaceController,WCSessionDelegate
{
    @IBOutlet var value: WKInterfaceLabel!
    var counter = 0
    var session:WCSession!
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        value.setText("\(counter)")
        if (WCSession.isSupported())
        {
            session = WCSession.defaultSession()
            session.delegate = self
            session.activateSession()
        }
        // Configure interface objects here.
    }

    override func willActivate()
    {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func saveAction()
    {
        session.sendMessage(["value":"\(counter)"], replyHandler: nil, errorHandler: nil)
    }
    
    @IBAction func hitAction()
    {
        counter = counter+1
        value.setText("\(counter)")
    }

    @IBAction func clearAction()
    {
        value.setText("0")
    }
}
