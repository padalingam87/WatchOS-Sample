//
//  ViewController.swift
//  41-TransferFile
//
//  Created by padalingam agasthian on 04/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UIViewController,WCSessionDelegate
{
    var session : WCSession!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        session = WCSession.defaultSession()
        session.delegate = self
        session.activateSession()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sendImage(sender: AnyObject)
    {
        if let fileURL = NSBundle.mainBundle().URLForResource("fancycat", withExtension: "jpg")
        {
            session.transferFile(fileURL, metadata: nil)
        }
        else
        {
            print("Could get fileURL")
        }
    }

}

