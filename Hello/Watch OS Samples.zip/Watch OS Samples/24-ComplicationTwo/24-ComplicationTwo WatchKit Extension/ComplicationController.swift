//
//  ComplicationController.swift
//  24-ComplicationTwo WatchKit Extension
//
//  Created by padalingam agasthian on 26/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import ClockKit


class ComplicationController: NSObject, CLKComplicationDataSource
{
    
    // MARK: - Timeline Configuration
    
    struct Content
    {
        var text:CLKSimpleTextProvider
        var ringStyle:CLKComplicationRingStyle
        var fillRect:Float
        
        var startDate:NSDate
        var length:NSTimeInterval
    }
    
    let contents = [
    Content(text: CLKSimpleTextProvider(text: "A"), ringStyle: .Open, fillRect: 0.5, startDate: NSDate(), length: 60*60*1),
    Content(text: CLKSimpleTextProvider(text: "B"), ringStyle: .Open, fillRect: 1.0, startDate: NSDate(timeIntervalSinceNow: 60*60*1), length: 60*60*1),
    Content(text: CLKSimpleTextProvider(text: "C"), ringStyle: .Open, fillRect: 0.7, startDate: NSDate(timeIntervalSinceNow: 60*60*2.5), length: 60*60*3)
    ]
    
    func getSupportedTimeTravelDirectionsForComplication(complication: CLKComplication, withHandler handler: (CLKComplicationTimeTravelDirections) -> Void) {
        handler([.Forward, .Backward])
    }
    
    func getTimelineStartDateForComplication(complication: CLKComplication, withHandler handler: (NSDate?) -> Void) {
        handler(nil)
    }
    
    func getTimelineEndDateForComplication(complication: CLKComplication, withHandler handler: (NSDate?) -> Void) {
        handler(nil)
    }
    
    func getPrivacyBehaviorForComplication(complication: CLKComplication, withHandler handler: (CLKComplicationPrivacyBehavior) -> Void) {
        handler(.ShowOnLockScreen)
    }
    
    // MARK: - Timeline Population
    
    func getCurrentTimelineEntryForComplication(complication: CLKComplication, withHandler handler: ((CLKComplicationTimelineEntry?) -> Void))
    {
        let content = contents[0]
        let template = CLKComplicationTemplateModularSmallRingText()
        template.textProvider = content.text
        template.ringStyle = content.ringStyle
        template.fillFraction = content.fillRect
        let entry = CLKComplicationTimelineEntry(date: content.startDate, complicationTemplate: template)
        handler(entry)
    }
    
    func getTimelineEntriesForComplication(complication: CLKComplication, beforeDate date: NSDate, limit: Int, withHandler handler: (([CLKComplicationTimelineEntry]?) -> Void)) {
        // Call the handler with the timeline entries prior to the given date
        handler(nil)
    }
    
    func getTimelineEntriesForComplication(complication: CLKComplication, afterDate date: NSDate, limit: Int, withHandler handler: (([CLKComplicationTimelineEntry]?) -> Void))
    {
        var entries:[CLKComplicationTimelineEntry]=[]
        for content in contents
        {
            if contents.count < limit && content.startDate.timeIntervalSinceDate(date) > 0
            {
                let template = CLKComplicationTemplateModularSmallRingText()
                template.textProvider = content.text
                template.ringStyle = content.ringStyle
                template.fillFraction = content.fillRect
                let entry = CLKComplicationTimelineEntry(date: NSDate(timeInterval: 60*60 * -0.25, sinceDate: content.startDate), complicationTemplate: template)
                entries.append(entry)
            }
        }
        handler(entries)
    }
    
    // MARK: - Update Scheduling
    
    func getNextRequestedUpdateDateWithHandler(handler: (NSDate?) -> Void) {
        // Call the handler with the date when you would next like to be given the opportunity to update your complication content
        handler(nil);
    }
    
    // MARK: - Placeholder Templates
    
    func getPlaceholderTemplateForComplication(complication: CLKComplication, withHandler handler: (CLKComplicationTemplate?) -> Void)
    {
        let template = CLKComplicationTemplateModularSmallRingText()
        template.textProvider = CLKSimpleTextProvider(text: "Modular Small")
        template.ringStyle = .Open
        template.fillFraction = 1.0
        handler(template)
    }
    
}
