//
//  InterfaceController.swift
//  35-TableAnimation WatchKit Extension
//
//  Created by padalingam agasthian on 29/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController
{
    @IBOutlet weak var table: WKInterfaceTable!
    var numberOfRows: Int = 3
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        table.setNumberOfRows(numberOfRows, withRowType: "Cell")
        loadTableData()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    private func loadTableData()
    {
        for (var i=0; i<numberOfRows; i++) {
            let row = table.rowControllerAtIndex(i) as! RowController
            row.showItem("\(i)", detail: "")
        }
    }
    
    @IBAction func removeAction()
    {
        if numberOfRows <= 1
        {
            return
        }
        table.removeRowsAtIndexes(NSIndexSet(index: 0))
        numberOfRows--
        loadTableData()
    }
    
    @IBAction func insertAction()
    {
        table.insertRowsAtIndexes(NSIndexSet(index: 0), withRowType: "Cell")
        numberOfRows++
        loadTableData()
    }
}
