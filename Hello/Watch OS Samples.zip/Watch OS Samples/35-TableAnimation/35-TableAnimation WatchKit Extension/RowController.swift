//
//  RowController.swift
//  35-TableAnimation
//
//  Created by padalingam agasthian on 29/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit

class RowController: NSObject
{
    @IBOutlet weak var textLabel: WKInterfaceLabel!
    @IBOutlet weak var detailLabel: WKInterfaceLabel!
    
    func showItem(title: String, detail: String)
    {
        
        textLabel.setText(title)
        detailLabel.setText(detail)
    }

}
