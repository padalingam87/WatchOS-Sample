//
//  InterfaceController.swift
//  5-DynamicTable WatchKit Extension
//
//  Created by padalingam agasthian on 22/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation

class InterfaceController: WKInterfaceController
{
    @IBOutlet var table: WKInterfaceTable!
    @IBOutlet var deleteButton: WKInterfaceButton!
    @IBOutlet var addButton: WKInterfaceButton!
    var arrayList = [1001]
    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        table.setNumberOfRows(arrayList.count, withRowType: "RowController")
        for (index,value) in arrayList.enumerate()
        {
            let row = table.rowControllerAtIndex(index) as? RowController
            row?.rollNo.setText("\(value)")
        }
        deleteButton.setEnabled(false)
        // Configure interface objects here.
    }

    override func willActivate()
    {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate()
    {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func addRow()
    {
        if arrayList.count >= 1
        {
            let value = arrayList[arrayList.count-1]
            arrayList.append(value+1)
            table.setNumberOfRows(arrayList.count, withRowType: "RowController")
            for (index,value) in arrayList.enumerate()
            {
                let row = table.rowControllerAtIndex(index) as? RowController
                row?.rollNo.setText("\(value)")
            }
            deleteButton.setEnabled(true)
        }
    }

    @IBAction func deleteRow()
    {
        if arrayList.count > 1
        {
            table.removeRowsAtIndexes(NSIndexSet(index: arrayList.count-1))
            arrayList.removeAtIndex(arrayList.count-1)
            table.setNumberOfRows(arrayList.count, withRowType: "RowController")
            for (index,value) in arrayList.enumerate()
            {
                let row = table.rowControllerAtIndex(index) as? RowController
                row?.rollNo.setText("\(value)")
            }
        }
        else
        {
             deleteButton.setEnabled(false)
        }
    }
}
