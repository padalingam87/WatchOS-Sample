//
//  ViewController.swift
//  39-NotificationOne
//
//  Created by padalingam agasthian on 03/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var timeStepper: UIStepper!
    let sharedDefaults =
    NSUserDefaults(suiteName: "group.com.example.NotifyDemoApp")
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if let timeValue = sharedDefaults?.doubleForKey("timeDelay") {
            timeStepper.value = timeValue
        } else
        {
            sharedDefaults?.setDouble(10.0, forKey: "timeDelay")
            timeStepper.value = 10.0
        }
        
        timeLabel.text =
            sharedDefaults?.doubleForKey("timeDelay").description
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func valueChanged(sender: AnyObject)
    {
        timeLabel.text = timeStepper.value.description
        sharedDefaults?.setDouble(timeStepper.value, forKey: "timeDelay")
    }
    
    @IBAction func buttonPress(sender: AnyObject)
    {
        setNotification()
    }
    
    func setNotification()
    {
        
        if let timeValue = sharedDefaults?.doubleForKey("timeDelay") {
            let localNotification:UILocalNotification =
            UILocalNotification()
            
            localNotification.alertTitle = "Reminder"
            
            localNotification.alertBody = "Wake Up!"
            
            localNotification.fireDate = NSDate(timeIntervalSinceNow:
                timeValue)
            localNotification.soundName =
            UILocalNotificationDefaultSoundName
            localNotification.category = "REMINDER_CATEGORY"
            
            
            UIApplication.sharedApplication().scheduleLocalNotification(
                localNotification)
        }
    }
}

