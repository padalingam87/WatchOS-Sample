//
//  InterfaceController.swift
//  39-NotificationOne WatchKit Extension
//
//  Created by padalingam agasthian on 03/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController
{
    @IBOutlet weak var timeLabel: WKInterfaceLabel!
    @IBOutlet weak var timeSlider: WKInterfaceSlider!
    var sliderValue: Double?
    
    let sharedDefaults =
    NSUserDefaults(suiteName: "group.com.example.NotifyDemoApp")

    override func awakeWithContext(context: AnyObject?)
    {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
    }

    @IBAction func stepper(value: Float)
    {
        sliderValue = Double(value)
        timeLabel.setText((value.description))
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func setDelay()
    {
        sharedDefaults?.setDouble(sliderValue!, forKey: "timeDelay")
    }

}
