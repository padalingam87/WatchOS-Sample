//
//  InterfaceController.swift
//  14-Video WatchKit Extension
//
//  Created by padalingam agasthian on 24/02/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var myMoviePlayer: WKInterfaceMovie!
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
    }

    override func willActivate()
    {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        let url = NSURL.init(fileURLWithPath:"/Users/padalingam.a/Desktop/My Projects/Watch OS/Watch OS Samples/14-Video/14-Video WatchKit App/test.mov")
      
        self.myMoviePlayer.setMovieURL(url)
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
